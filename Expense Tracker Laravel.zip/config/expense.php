<?php

return [
    'expense_category' => ['Household', 'Medicines', 'Travel', 'Food', 'Misc'],

    'payment_method' => ['Cash', 'Credit Card', 'Bank'],
];
