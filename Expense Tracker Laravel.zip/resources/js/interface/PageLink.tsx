interface PageLink {
  active: boolean;
  label: string;
  url: string | null;
}

export default PageLink;
